# Neon Aim — pacote corrigido para compilar APK

Este ZIP contém o projeto Android nativo em Kotlin/Jetpack Compose e uma automação GitHub Actions para compilar o APK em um servidor, sem precisar instalar Android Studio no celular.

## Importante
Este arquivo ZIP **não é um APK**. Ele contém o código-fonte e a configuração para gerar o APK. O app é um simulador independente de treino de mira; não controla outros jogos nem inclui aimbot, ESP em jogos de terceiros ou funções anti-ban.

## Gerar o APK usando apenas o celular
1. Baixe e extraia este ZIP no celular.
2. No navegador, entre em https://github.com e crie uma conta ou entre na sua conta.
3. Crie um repositório novo chamado `NeonAim` e deixe-o vazio.
4. Envie os arquivos e pastas deste projeto para o repositório, preservando a estrutura e incluindo a pasta oculta `.github/workflows`. Se o envio pelo navegador não aceitar pastas, use o envio de arquivos do GitHub ou o aplicativo/cliente Git que preferir.
5. Abra a aba **Actions** do repositório. Se pedir, confirme a ativação de workflows.
6. Selecione **Gerar APK Neon Aim** e toque em **Run workflow**.
7. Aguarde a execução terminar com marca verde. Abra a execução concluída e procure **Artifacts** > `NeonAim-debug-apk`.
8. Baixe o artefato ZIP, extraia-o e toque em `app-debug.apk` para instalar. Se o Android perguntar, permita a instalação dessa fonte.

## Se a compilação falhar
Abra a execução na aba Actions e copie a parte vermelha do log de erro. Envie o texto ou uma captura de tela para que o erro específico possa ser corrigido.

## Requisitos técnicos
Android SDK Platform 35, Build Tools 35.0.0, JDK 17 e Gradle 8.9 são configurados pelo workflow.
